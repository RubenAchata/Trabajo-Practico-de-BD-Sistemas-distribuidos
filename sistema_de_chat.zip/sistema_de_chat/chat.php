<?php
session_start();
require 'conexion.php';


if (!isset($_SESSION['id_usuario'])) {
    header('Location: login.php');
    exit;
}


$idGrupo = $_GET['id'] ?? 0;


if (isset($_POST['abandonar_grupo'])) {
    $stmtSalir = $pdo->prepare("DELETE FROM es_miembro WHERE id_grupo_fk = ? AND id_usuario_fk = ?");
    $stmtSalir->execute([$idGrupo, $_SESSION['id_usuario']]);
    header('Location: dashboard.php');
    exit;
}


$stmt = $pdo->prepare("
    SELECT g.*, em.mostrar_apodo, em.pseudonimo FROM grupo g
    JOIN es_miembro em ON g.id_grupo_pk = em.id_grupo_fk
    WHERE g.id_grupo_pk = ? AND em.id_usuario_fk = ?
");
$stmt->execute([$idGrupo, $_SESSION['id_usuario']]);
$grupo = $stmt->fetch();


if (!$grupo) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Chat - <?= htmlspecialchars($grupo['nombre']) ?></title>
    <style>
        * { box-sizing: border-box; font-family: system-ui, sans-serif; }
        body { background: #eef2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
       
        .container { width: 100%; max-width: 950px; height: 90vh; background: white; border-radius: 8px; display: flex; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden; }
       
        .chat-section { flex: 1; display: flex; flex-direction: column; border-right: 1px solid #e0e0e0; }
        .header { padding: 12px 15px; background: #0d6efd; color: white; display: flex; justify-content: space-between; align-items: center; }
        .messages { flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; background: #f8f9fa; }
        .msg { max-width: 75%; padding: 8px 12px; border-radius: 8px; font-size: 0.9rem; word-break: break-word; position: relative; display: flex; flex-direction: column; }
        .msg.mio { align-self: flex-end; background: #d1e7dd; }
        .msg.otro { align-self: flex-start; background: #e2e3e5; }
        .msg img { max-width: 100%; max-height: 250px; border-radius: 6px; margin-top: 5px; display: block; object-fit: contain; }
        .msg-time { font-size: 0.7rem; color: #666; align-self: flex-end; margin-top: 4px; }
       
        .btn-reportar { position: absolute; top: 4px; right: 6px; font-size: 0.65rem; color: #a00; border: none; background: transparent; cursor: pointer; opacity: 0.6; }
        .btn-reportar:hover { opacity: 1; text-decoration: underline; }


        .input-box { display: flex; padding: 10px; border-top: 1px solid #ddd; gap: 6px; align-items: center; }
        .input-box input[type="text"] { flex: 1; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        .input-box button { padding: 10px 15px; background: #0d6efd; color: white; border: none; border-radius: 4px; cursor: pointer; }
       
        .btn-action { background: rgba(255,255,255,0.2); color: white; border: 1px solid white; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.75rem; }
        .btn-action:hover { background: rgba(255,255,255,0.3); }


        .sidebar { width: 260px; background: #ffffff; display: flex; flex-direction: column; }
        .sidebar-header { padding: 14px 15px; background: #f1f3f5; border-bottom: 1px solid #e0e0e0; font-weight: bold; font-size: 0.95rem; color: #333; }
        .sidebar-content { flex: 1; padding: 10px 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; }
        .miembro-card { display: flex; justify-content: space-between; align-items: center; padding: 8px 10px; background: #f8f9fa; border-radius: 6px; border: 1px solid #eee; }
        .miembro-info { display: flex; flex-direction: column; overflow: hidden; }
        .miembro-nombre { font-size: 0.85rem; font-weight: 600; color: #212529; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Panel Izquierdo: Chat -->
        <div class="chat-section">
            <div class="header">
                <div>
                    <strong><?= htmlspecialchars($grupo['nombre']) ?></strong>
                    <br><small><a href="dashboard.php" style="color:white;">← Volver al panel</a></small>
                </div>
                <div style="text-align: right;">
                    <button onclick="toggleVisibilidad()" class="btn-action">👁 Cambiar Nombre/Apodo</button>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('¿Querés abandonar este grupo?');">
                        <button type="submit" name="abandonar_grupo" class="btn-action" style="background:#dc3545; border:none;">Salir</button>
                    </form>
                </div>
            </div>


            <div class="messages" id="msgs"></div>


            <form id="formChat" class="input-box" onsubmit="enviar(event)" enctype="multipart/form-data">
                <input type="text" id="txtMsg" placeholder="Escribe un mensaje..." autocomplete="off">
                <input type="file" id="fileImg" accept="image/*" style="width: auto; border:none;">
                <button type="submit">Enviar</button>
            </form>
        </div>


        <!-- Panel Derecha: Integrantes (sin etiqueta de rol) -->
        <div class="sidebar">
            <div class="sidebar-header">👥 Integrantes</div>
            <div class="sidebar-content" id="listaMiembros">
                <small style="color:#666;">Cargando integrantes...</small>
            </div>
        </div>
    </div>


<script>
    const idGrupo = <?= (int)$idGrupo ?>;
    const idUsuario = <?= (int)$_SESSION['id_usuario'] ?>;
    let ultimoId = 0;


    async function cargar() {
        try {
            const res = await fetch(`api_chat.php?action=obtener&grupo_id=${idGrupo}&ultimo_id=${ultimoId}`);
            const data = await res.json();


            if (Array.isArray(data) && data.length > 0) {
                const container = document.getElementById('msgs');
                data.forEach(m => {
                    const div = document.createElement('div');
                    const esMio = parseInt(m.emisor_id_fk) === idUsuario;
                    const emisorNombre = parseInt(m.mostrar_apodo) === 1 ? (m.pseudonimo || 'Anónimo') : `${m.nombre} ${m.apellido}`;


                    div.className = `msg ${esMio ? 'mio' : 'otro'}`;
                   
                    let htmlContenido = `
                        <button class="btn-reportar" onclick="reportarMensaje()">🚩 Reportar</button>
                        <div><strong>${esMio ? 'Tú' : emisorNombre}:</strong></div>
                    `;


                    if (m.contenido) {
                        htmlContenido += `<div>${m.contenido}</div>`;
                    }


                    if (m.imagen_url) {
                        htmlContenido += `<img src="${m.imagen_url}" alt="Imagen subida">`;
                    }


                    htmlContenido += `<span class="msg-time">${m.hora} hs</span>`;


                    div.innerHTML = htmlContenido;
                    container.appendChild(div);
                    ultimoId = m.id_mensaje_pk;
                });
                container.scrollTop = container.scrollHeight;
            }
        } catch (e) {
            console.error("Error al obtener mensajes", e);
        }
    }


    async function cargarMiembros() {
        try {
            const res = await fetch(`api_chat.php?action=obtener_miembros&grupo_id=${idGrupo}`);
            const miembros = await res.json();


            if (Array.isArray(miembros)) {
                const listaDiv = document.getElementById('listaMiembros');
                listaDiv.innerHTML = '';


                miembros.forEach(m => {
                    const esYo = parseInt(m.id_usuario_pk) === idUsuario;
                    const nombreMostrar = parseInt(m.mostrar_apodo) === 1 ? (m.pseudonimo || 'Anónimo') : `${m.nombre} ${m.apellido}`;


                    const item = document.createElement('div');
                    item.className = 'miembro-card';
                    item.innerHTML = `
                        <div class="miembro-info">
                            <span class="miembro-nombre" title="${nombreMostrar}">${nombreMostrar} ${esYo ? '(Tú)' : ''}</span>
                        </div>
                    `;
                    listaDiv.appendChild(item);
                });
            }
        } catch (e) {
            console.error("Error al obtener integrantes", e);
        }
    }


    async function enviar(event) {
        if (event) event.preventDefault();


        const inputTxt = document.getElementById('txtMsg');
        const inputImg = document.getElementById('fileImg');
        const txt = inputTxt.value.trim();
        const file = inputImg.files[0];


        if (!txt && !file) return;


        const formData = new FormData();
        formData.append('id_grupo', idGrupo);
        formData.append('mensaje', txt);
        if (file) {
            formData.append('imagen', file);
        }


        inputTxt.value = '';
        inputImg.value = '';


        await fetch('api_chat.php?action=enviar', {
            method: 'POST',
            body: formData
        });


        cargar();
    }


    async function toggleVisibilidad() {
        await fetch(`api_chat.php?action=toggle_visibilidad&grupo_id=${idGrupo}`);
       
        const res = await fetch(`api_chat.php?action=obtener_miembros&grupo_id=${idGrupo}`);
        const miembros = await res.json();
        const yo = miembros.find(m => parseInt(m.id_usuario_pk) === idUsuario);


        if (yo) {
            const esApodo = parseInt(yo.mostrar_apodo) === 1;
            const nombreActual = esApodo ? (yo.pseudonimo || 'Anónimo') : `${yo.nombre} ${yo.apellido}`;
            alert(`Visibilidad cambiada.\nAhora te ves como: "${nombreActual}" (${esApodo ? 'Apodo' : 'Nombre Real'})`);
        }


        document.getElementById('msgs').innerHTML = '';
        ultimoId = 0;
        cargar();
        cargarMiembros();
    }


    function reportarMensaje() {
        alert('Reportado');
    }


    setInterval(() => {
        cargar();
        cargarMiembros();
    }, 1500);


    cargar();
    cargarMiembros();
</script>
</body>
</html>
