<?php
session_start();
require 'conexion.php';

if (isset($_SESSION['id_usuario'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gmail = trim($_POST['gmail']);
    $password = trim($_POST['password']);

    if (!empty($gmail) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM usuario WHERE gmail = ?");
        $stmt->execute([$gmail]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($password, $usuario['password'])) {
            $_SESSION['id_usuario'] = $usuario['id_usuario_pk'];
            $_SESSION['nombre_completo'] = $usuario['nombre'] . ' ' . $usuario['apellido'];
            $_SESSION['rol'] = $usuario['rol'];

            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Credenciales incorrectas.";
        }
    } else {
        $error = "Por favor completá todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - Escuela Técnica Fragata Libertad</title>
    <style>
        * { box-sizing: border-box; font-family: system-ui, sans-serif; }
        body { background: #f4f6f8; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 10px; width: 360px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-top: 0; color: #0d6efd; }
        input { width: 100%; padding: 10px; margin: 8px 0 15px 0; border: 1px solid #ccc; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #0d6efd; color: white; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; }
        .error { color: #dc3545; font-size: 0.85rem; text-align: center; }
        .footer { text-align: center; margin-top: 15px; font-size: 0.85rem; }
        .footer a { color: #0d6efd; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Iniciar Sesión</h2>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <?php if (isset($_GET['registrado'])): ?><p style="color:green; text-align:center; font-size:0.85rem;">¡Registro exitoso! Ya podés ingresar.</p><?php endif; ?>

        <form method="POST">
            <input type="email" name="gmail" placeholder="Correo electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Ingresar</button>
        </form>

        <div class="footer">
            ¿No tenés cuenta? <a href="signup.php">Registrate acá</a>
        </div>
    </div>
</body>
</html>