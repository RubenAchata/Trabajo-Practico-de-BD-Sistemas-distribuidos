<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    header('Location: login.php');
    exit;
}

$msg = '';
$solicitarApodo = false;
$idGrupoPendiente = 0;
$nombreGrupoPendiente = '';
$codigoNuevoGrupo = '';

// 1. Crear Grupo (Muestra el código generado)
if (isset($_POST['crear_grupo'])) {
    $nombreGrupo = trim($_POST['nombre_grupo']);
    // Genera un código único de 6 caracteres
    $codigo = strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));

    if (!empty($nombreGrupo)) {
        $stmt = $pdo->prepare("INSERT INTO grupo (nombre, codigo_vinculacion, user_crea_fk) VALUES (?, ?, ?)");
        $stmt->execute([$nombreGrupo, $codigo, $_SESSION['id_usuario']]);
        $idGrupo = $pdo->lastInsertId();

        // Asigna por defecto "Anónimo" o su Nombre al creador
        $stmtM = $pdo->prepare("INSERT INTO es_miembro (id_grupo_fk, id_usuario_fk, pseudonimo) VALUES (?, ?, ?)");
        $stmtM->execute([$idGrupo, $_SESSION['id_usuario'], $_SESSION['nombre_completo']]);

        $codigoNuevoGrupo = $codigo;
    }
}

// 2. Verificar Código y Activar Modal de Apodo (ANTES de ingresar)
if (isset($_POST['buscar_codigo'])) {
    $codigo = strtoupper(trim($_POST['codigo_vinculacion']));

    $stmt = $pdo->prepare("SELECT * FROM grupo WHERE codigo_vinculacion = ?");
    $stmt->execute([$codigo]);
    $grupo = $stmt->fetch();

    if ($grupo) {
        $stmtCheck = $pdo->prepare("SELECT * FROM es_miembro WHERE id_grupo_fk = ? AND id_usuario_fk = ?");
        $stmtCheck->execute([$grupo['id_grupo_pk'], $_SESSION['id_usuario']]);
        
        if ($stmtCheck->fetch()) {
            // Si ya era miembro, entra directo
            header("Location: chat.php?id=" . $grupo['id_grupo_pk']);
            exit;
        } else {
            // Muestra la ventana flotante para elegir apodo ANTES de entrar
            $solicitarApodo = true;
            $idGrupoPendiente = $grupo['id_grupo_pk'];
            $nombreGrupoPendiente = $grupo['nombre'];
        }
    } else {
        $msg = "El código de vinculación no existe.";
    }
}

// 3. Confirmar Apodo y Entrar al Chat
if (isset($_POST['confirmar_apodo'])) {
    $idGrupo = (int)$_POST['id_grupo'];
    $pseudonimo = trim($_POST['pseudonimo']);

    // Si deja el campo vacío o elige por defecto, asigna "Anónimo"
    if (empty($pseudonimo)) {
        $pseudonimo = 'Anónimo';
    }

    $stmtM = $pdo->prepare("INSERT INTO es_miembro (id_grupo_fk, id_usuario_fk, pseudonimo) VALUES (?, ?, ?)");
    $stmtM->execute([$idGrupo, $_SESSION['id_usuario'], $pseudonimo]);

    header("Location: chat.php?id=" . $idGrupo);
    exit;
}

// 4. Salir de un Grupo
if (isset($_POST['salir_grupo'])) {
    $idGrupoSalir = (int)$_POST['id_grupo_salir'];
    $stmtSalir = $pdo->prepare("DELETE FROM es_miembro WHERE id_grupo_fk = ? AND id_usuario_fk = ?");
    $stmtSalir->execute([$idGrupoSalir, $_SESSION['id_usuario']]);
    header('Location: dashboard.php');
    exit;
}

$stmtMisGrupos = $pdo->prepare("
    SELECT g.* FROM grupo g
    JOIN es_miembro em ON g.id_grupo_pk = em.id_grupo_fk
    WHERE em.id_usuario_fk = ?
");
$stmtMisGrupos->execute([$_SESSION['id_usuario']]);
$misGrupos = $stmtMisGrupos->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Grupos</title>
    <style>
        * { box-sizing: border-box; font-family: system-ui, sans-serif; }
        body { background: #f4f6f8; padding: 30px; }
        .nav { max-width: 800px; margin: 0 auto 20px; display: flex; justify-content: space-between; align-items: center; }
        .grid { display: flex; gap: 20px; max-width: 800px; margin: 0 auto; flex-wrap: wrap; }
        .card { background: white; padding: 20px; border-radius: 8px; flex: 1; min-width: 300px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        input, button { width: 100%; padding: 10px; margin-top: 10px; border-radius: 5px; border: 1px solid #ccc; }
        button { background: #198754; color: white; border: none; font-weight: bold; cursor: pointer; }
        button.blue { background: #0d6efd; }
        .alert-success { background: #d1e7dd; color: #0f5132; padding: 12px; border-radius: 6px; border: 1px solid #badbcc; margin-bottom: 15px; }
        .group-list { list-style: none; padding: 0; margin: 0; }
        .group-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #eee; }
        .btn-salir { background: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 0.8rem; width: auto; margin: 0; }
        
        /* Modal para elegir apodo */
        .modal { display: <?= $solicitarApodo ? 'flex' : 'none' ?>; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: white; padding: 25px; border-radius: 8px; width: 90%; max-width: 400px; text-align: center; }
    </style>
</head>
<body>
    <div class="nav">
        <div>
            <h2>Bienvenido, <?= htmlspecialchars($_SESSION['nombre_completo']) ?></h2>
            <small style="background:#e2e3e5; padding:3px 8px; border-radius:4px;"><?= htmlspecialchars($_SESSION['rol']) ?></small>
        </div>
        <a href="logout.php" style="color:#dc3545; font-weight:bold;">Cerrar Sesión</a>
    </div>

    <div style="max-width:800px; margin:0 auto;">
        <?php if ($msg): ?><p style="color:red; text-align:center;"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
        
        <!-- Cartel al crear un grupo mostrando el código de vinculación -->
        <?php if ($codigoNuevoGrupo): ?>
            <div class="alert-success">
                <strong>¡Grupo creado con éxito!</strong><br>
                El código para compartir y que otros se vinculen es: <strong style="font-size:1.2rem; font-family:monospace;"><?= $codigoNuevoGrupo ?></strong>
            </div>
        <?php endif; ?>
    </div>

    <div class="grid">
        <div class="card">
            <h3>Unirse con Código</h3>
            <form method="POST">
                <input type="text" name="codigo_vinculacion" placeholder="Código de vinculación" maxlength="6" required>
                <button type="submit" name="buscar_codigo" class="blue">Continuar</button>
            </form>
        </div>

        <div class="card">
            <h3>Crear nuevo grupo</h3>
            <form method="POST">
                <input type="text" name="nombre_grupo" placeholder="Nombre del Grupo" required>
                <button type="submit" name="crear_grupo">Crear Grupo</button>
            </form>
        </div>
    </div>

    <?php if (count($misGrupos) > 0): ?>
    <div style="max-width: 800px; margin: 30px auto 0;">
        <h3>Mis Grupos Activos</h3>
        <div class="card">
            <ul class="group-list">
                <?php foreach ($misGrupos as $g): ?>
                    <li class="group-item">
                        <div>
                            👉 <a href="chat.php?id=<?= $g['id_grupo_pk'] ?>"><strong><?= htmlspecialchars($g['nombre']) ?></strong></a> 
                            <small style="color:#666;">(Código: <code><?= $g['codigo_vinculacion'] ?></code>)</small>
                        </div>
                        <form method="POST" style="margin:0;" onsubmit="return confirm('¿Seguro que querés salir de este grupo?');">
                            <input type="hidden" name="id_grupo_salir" value="<?= $g['id_grupo_pk'] ?>">
                            <button type="submit" name="salir_grupo" class="btn-salir">Salir</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <!-- Modal de Selección de Apodo antes de ingresar al chat -->
    <div class="modal">
        <div class="modal-content">
            <h3>Seleccionar Apodo</h3>
            <p style="font-size:0.85rem; color:#666;">Vas a ingresar a "<strong><?= htmlspecialchars($nombreGrupoPendiente) ?></strong>". Escribí tu apodo o dejalo en <i>Anónimo</i>:</p>
            <form method="POST">
                <input type="hidden" name="id_grupo" value="<?= $idGrupoPendiente ?>">
                <input type="text" name="pseudonimo" placeholder="Anónimo" value="Anónimo">
                <button type="submit" name="confirmar_apodo" class="blue">Entrar al Chat</button>
            </form>
        </div>
    </div>
    <div class="nav">
    <div>
        <h2>Bienvenido, <?= htmlspecialchars($_SESSION['nombre_completo']) ?></h2>
    </div>
    <a href="logout.php" style="color:#dc3545; font-weight:bold;">Cerrar Sesión</a>
</div>
</body>
</html>