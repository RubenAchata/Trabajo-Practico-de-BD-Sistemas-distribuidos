<?php
session_start();
require 'conexion.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$action = $_GET['action'] ?? '';

// 1. Alternar Visibilidad
if ($action === 'toggle_visibilidad') {
    $idGrupo = (int)($_GET['grupo_id'] ?? 0);
    $stmt = $pdo->prepare("UPDATE es_miembro SET mostrar_apodo = NOT mostrar_apodo WHERE id_grupo_fk = ? AND id_usuario_fk = ?");
    $stmt->execute([$idGrupo, $_SESSION['id_usuario']]);
    echo json_encode(['status' => 'ok']);
    exit;
}

// 2. Obtener Miembros
if ($action === 'obtener_miembros') {
    $idGrupo = (int)($_GET['grupo_id'] ?? 0);
    $stmt = $pdo->prepare("
        SELECT u.id_usuario_pk, u.nombre, u.apellido, u.rol, 
               COALESCE(em.pseudonimo, 'Anónimo') AS pseudonimo, 
               COALESCE(em.mostrar_apodo, 1) AS mostrar_apodo 
        FROM usuario u
        JOIN es_miembro em ON u.id_usuario_pk = em.id_usuario_fk
        WHERE em.id_grupo_fk = ? ORDER BY u.nombre ASC
    ");
    $stmt->execute([$idGrupo]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// 3. Obtener Mensajes con Hora (DATE_FORMAT)
if ($action === 'obtener') {
    $idGrupo = (int)($_GET['grupo_id'] ?? 0);
    $ultimoId = (int)($_GET['ultimo_id'] ?? 0);

    $stmt = $pdo->prepare("
        SELECT 
            m.id_mensaje_pk, 
            m.contenido, 
            m.imagen_url, 
            DATE_FORMAT(m.fecha_hora, '%H:%i') AS hora,
            m.emisor_id_fk,
            u.nombre, 
            u.apellido, 
            u.rol,
            COALESCE(em.pseudonimo, 'Anónimo') AS pseudonimo,
            COALESCE(em.mostrar_apodo, 1) AS mostrar_apodo
        FROM mensaje m
        JOIN usuario u ON m.emisor_id_fk = u.id_usuario_pk
        LEFT JOIN es_miembro em ON (em.id_grupo_fk = m.grupo_id_fk AND em.id_usuario_fk = m.emisor_id_fk)
        WHERE m.grupo_id_fk = ? AND m.id_mensaje_pk > ?
        ORDER BY m.id_mensaje_pk ASC
    ");
    $stmt->execute([$idGrupo, $ultimoId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// 4. Enviar Mensaje
if ($action === 'enviar') {
    $idGrupo = (int)($_POST['id_grupo'] ?? 0);
    $mensaje = trim($_POST['mensaje'] ?? '');
    $rutaImagen = null;

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        if ($_FILES['imagen']['size'] <= 5 * 1024 * 1024) {
            $fileTmpPath = $_FILES['imagen']['tmp_name'];
            $fileName = $_FILES['imagen']['name'];
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $checkImage = getimagesize($fileTmpPath);

            if (in_array($fileExtension, $allowedExtensions) && $checkImage !== false) {
                $uploadDir = 'uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }

                $newFileName = time() . '_' . md5(uniqid(rand(), true)) . '.' . $fileExtension;
                $destPath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    $rutaImagen = $destPath;
                }
            }
        }
    }

    if (!empty($mensaje) || $rutaImagen !== null) {
        $stmt = $pdo->prepare("INSERT INTO mensaje (contenido, imagen_url, emisor_id_fk, grupo_id_fk) VALUES (?, ?, ?, ?)");
        $stmt->execute([$mensaje, $rutaImagen, $_SESSION['id_usuario'], $idGrupo]);
        echo json_encode(['status' => 'ok']);
    } else {
        echo json_encode(['error' => 'Datos inválidos']);
    }
    exit;
}