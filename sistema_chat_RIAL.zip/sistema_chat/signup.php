<?php
session_start();
require 'conexion.php';

if (isset($_SESSION['id_usuario'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $dni = trim($_POST['dni']);
    $rol = $_POST['rol'] ?? '';
    $gmail = trim($_POST['gmail']);
    $telefono = trim($_POST['telefono']);
    $password = trim($_POST['password']);

    if (!empty($nombre) && !empty($apellido) && !empty($dni) && !empty($rol) && !empty($gmail) && !empty($telefono) && !empty($password)) {
        
        $stmtCheck = $pdo->prepare("SELECT id_usuario_pk FROM usuario WHERE gmail = ? OR dni = ?");
        $stmtCheck->execute([$gmail, $dni]);
        
        if ($stmtCheck->fetch()) {
            $error = "El email o el DNI ya se encuentran registrados.";
        } else {
            $passHash = password_hash($password, PASSWORD_BCRYPT);
            
            $stmt = $pdo->prepare("
                INSERT INTO usuario (nombre, apellido, dni, rol, gmail, telefono_resp, password) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$nombre, $apellido, $dni, $rol, $gmail, $telefono, $passHash]);

            header('Location: login.php?registrado=1');
            exit;
        }
    } else {
        $error = "Por favor completá todos los campos obligatorios.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - Escuela Técnica Fragata Libertad</title>
    <style>
        * { box-sizing: border-box; font-family: system-ui, sans-serif; }
        body { background: #f4f6f8; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 20px 0; }
        .box { background: white; padding: 30px; border-radius: 10px; width: 420px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-top: 0; color: #0d6efd; }
        p.subtitle { text-align: center; font-size: 0.85rem; color: #666; margin-bottom: 20px; }
        label { font-size: 0.85rem; font-weight: bold; color: #555; display: block; margin-top: 8px; }
        input, select { width: 100%; padding: 10px; margin: 4px 0 10px 0; border: 1px solid #ccc; border-radius: 5px; }
        button { width: 100%; padding: 11px; background: #198754; color: white; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        .error { color: #dc3545; font-size: 0.85rem; text-align: center; }
        .footer { text-align: center; margin-top: 15px; font-size: 0.9rem; }
        .footer a { color: #0d6efd; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Crear Cuenta</h2>
        <p class="subtitle">Escuela Técnica Fragata Libertad</p>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

        <form method="POST">
            <label>Datos Personales Reales</label>
            <input type="text" name="nombre" placeholder="Nombre completo" required>
            <input type="text" name="apellido" placeholder="Apellido completo" required>
            <input type="text" name="dni" placeholder="DNI del Alumno / Usuario" required>

            <label>Rol institucional</label>
            <select name="rol" required>
                <option value="">Selecciona tu rol...</option>
                <option value="Alumno">Alumno</option>
                <option value="Docente">Docente</option>
            </select>

            <label>Contacto y Tutor</label>
            <input type="email" name="gmail" placeholder="Correo electrónico / Gmail" required>
            <input type="text" name="telefono" placeholder="Número del Responsable / Tutor" required>

            <label>Seguridad</label>
            <input type="password" name="password" placeholder="Contraseña" required>

            <button type="submit">Registrarse</button>
        </form>

        <div class="footer">
            ¿Ya tenés cuenta? <a href="login.php">Iniciá sesión acá</a>
        </div>
    </div>
</body>
</html>